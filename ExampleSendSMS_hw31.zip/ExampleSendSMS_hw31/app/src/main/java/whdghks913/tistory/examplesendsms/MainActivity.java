package whdghks913.tistory.examplesendsms;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
    Context mContext;
    EditText smsNumber, smsTextContext;
    WebView web;
    String phoneNum;
    String msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        web = (WebView)findViewById(R.id.webkit);  //setting webView in activity
        mContext = this;
        web.getSettings().setJavaScriptEnabled(true);

        web.addJavascriptInterface(new JavascriptInterface(this), "Android"); //connect html file hosted in app
        web.loadUrl("file:///android_asset/webSMS.html");

    }
    public class JavascriptInterface{
        Context mContext;

        JavascriptInterface(Context c){
            mContext = c;
            msg = "";  //default msg and phon number is empty.
            phoneNum = "";
        }
        private void clear(){
            msg = "";
            phoneNum = "";
        }
        //setting some methods such as setting phone number / setting message / send phon number to html
        @android.webkit.JavascriptInterface
        public void setNum(String num) {
            phoneNum += num;
        }   //set phon number when the user input button on html
        @android.webkit.JavascriptInterface
        public void setMsg(String txt) {   //set message when the user input msg and click the button
            msg += txt;
            sendSMS();  //if user input send button then start to send message to other user whoes phone number is phonNum

        }
        @android.webkit.JavascriptInterface
        public String getNum() {
            return phoneNum;
        }   //if user input phon number button on html then show the number which get from html on html




    }
    
    public void sendSMS(){
        String smsNum = phoneNum;
        String smsText = msg;
        
        if (smsNum.length()>0 && smsText.length()>0){
            sendSMS(smsNum, smsText);
        }else{
            Toast.makeText(this, "type msg", Toast.LENGTH_SHORT).show();
        }
    }
    
    public void sendSMS(String smsNumber, String smsText){
        PendingIntent sentIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_SENT_ACTION"), 0);
        PendingIntent deliveredIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_DELIVERED_ACTION"), 0);
        

        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch(getResultCode()){
                    case Activity.RESULT_OK:
                        Toast.makeText(mContext, "ok", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:

                        Toast.makeText(mContext, "failure", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:

                        Toast.makeText(mContext, "no service", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:

                        Toast.makeText(mContext, "error of radio off", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:

                        Toast.makeText(mContext, "PDU Null", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter("SMS_SENT_ACTION"));
        
        /**
         * SMS�� ���������� ����
         * When the SMS massage has been delivered
         */
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (getResultCode()){
                    case Activity.RESULT_OK:
                        // ���� �Ϸ�
                        Toast.makeText(mContext, "SMS ok", Toast.LENGTH_SHORT).show();
                        break;
                    case Activity.RESULT_CANCELED:
                        // ���� �ȵ�
                        Toast.makeText(mContext, "SMS cancel", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter("SMS_DELIVERED_ACTION"));
        
        SmsManager mSmsManager = SmsManager.getDefault();
        mSmsManager.sendTextMessage(smsNumber, null, smsText, sentIntent, deliveredIntent);
    }
}
